#include "globals.h"

/* Global variables */

LONG_T n;
LONG_T m;

double a;
double b;
double c;
double d;

WEIGHT_T MAX_WEIGHT;
WEIGHT_T MIN_WEIGHT;

int SELF_LOOPS;

int STORE_IN_MEMORY;

int SORT_EDGELISTS;
int SORT_TYPE;
int WRITE_TO_FILE;

char OUTFILE[30];
char LOGFILE[30];
