#ifdef __STDC__
double    cputime(void);
#else
double    cputime();
#endif

